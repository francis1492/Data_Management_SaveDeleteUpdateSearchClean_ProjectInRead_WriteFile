﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement
{
    internal class Data
    {
        public int Id;
        public string Name;
        public int Age;
        public string Gender;
        public string Adress;
        public string PNumber;
        public DateTime DTime;

        public Data(string name, int age, string Gender, string adress, string PhoneNumber, DateTime dTime)
        {
            Name = name;
            Age = age;
            this.Gender = Gender;
            Adress = adress;
            PNumber = PhoneNumber;
            DTime = dTime;

        }

    }

}
